/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
    chuquiej

CONTROLDOR DEL USUARIO
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Articulo;
import modelo.ArticuloDAO;
import modelo.Categoria;
import modelo.CategoriaDAO;
import modelo.Compra;
import modelo.CompraDAO;
import modelo.ControlCalidad;
import modelo.ControlCalidadDAO;
import modelo.DetalleArticuloCompra;
import modelo.DetalleArticuloCompraDAO;
import modelo.Empleado;
import modelo.EmpleadoDAO;
import modelo.Factura;
import modelo.FacturaDAO;
import modelo.Marca;
import modelo.MarcaDAO;
import modelo.Persona;
import modelo.PersonaDAO;
import modelo.Proveedor;
import modelo.ProveedorDAO;
import modelo.Usuario;
import modelo.UsuarioDAO;

/**
 *
 * @author al3ja
 */
@WebServlet(name = "Controlador", urlPatterns = {"/Controlador"})
public class Controlador extends HttpServlet {

    //MARCA
    Marca marca = new Marca();
    MarcaDAO marcaDao = new MarcaDAO();
    int codMarca;

    //COMPRA
    Compra compra = new Compra();
    CompraDAO compraDao = new CompraDAO();
    int codCompra;

    //CATEGORIA
    Categoria categoria = new Categoria();
    CategoriaDAO categoriaDao = new CategoriaDAO();
    int codCategoria;

    //PROVEEDOR
    Proveedor proveedor = new Proveedor();
    ProveedorDAO proveedorDao = new ProveedorDAO();
    int codProveedor;

    //CONTROL CALIDAD
    ControlCalidad controlCalidad = new ControlCalidad();
    ControlCalidadDAO controlCalidadDao = new ControlCalidadDAO();
    int codControlCalidad;

    //Articulo
    Articulo articulo = new Articulo();
    ArticuloDAO articuloDao = new ArticuloDAO();
    int codArticulo;

    // Empleado
    Empleado empleado = new Empleado();
    EmpleadoDAO empleadoDAO = new EmpleadoDAO();
    int codEmpleado;

    //DetalleArticulocompra
    DetalleArticuloCompra detalleArticuloCompra = new DetalleArticuloCompra();
    DetalleArticuloCompraDAO detalleArticuloCompraDAO = new DetalleArticuloCompraDAO();
    int codDetalleArticuloCompra;

    // PERSONA
    Persona persona = new Persona();
    PersonaDAO personaDao = new PersonaDAO();
    int codPersona;

    //FACTURA
    Factura factura = new Factura();
    FacturaDAO facturaDao = new FacturaDAO();
    int codFactura;

    //USUARIO
    Usuario usuario = new Usuario();
    UsuarioDAO usuarioDao = new UsuarioDAO();
    int codUsuario;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");
        if (menu.equals("Principal")) {

            request.getRequestDispatcher("Principal.jsp").forward(request, response);

            //CRUD MARCA
        } else if (menu.equals("VistaMarca")) {
            switch (accion) {
                case "Listar":
                    List listaMarcas = marcaDao.listar();
                    request.setAttribute("marcas", listaMarcas);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaMarca.jsp").forward(request, response);

            //CRUD COMPRA
        } else if (menu.equals("VistaCompra")) {
            switch (accion) {
                case "Listar":
                    List listaCompra = compraDao.listar();
                    request.setAttribute("compra", listaCompra);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaCompra.jsp").forward(request, response);

            //CRUD CATEGORIA
        } else if (menu.equals("VistaCategoria")) {
            switch (accion) {
                case "Listar":
                    List listaCategoria = categoriaDao.listar();
                    request.setAttribute("categoria", listaCategoria);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaCategoria.jsp").forward(request, response);

            //CRUD CONTROL CALIDAD
        } else if (menu.equals("VistaControlCalidad")) {
            switch (accion) {
                case "Listar":
                    List listaControlCalidad = controlCalidadDao.listar();
                    request.setAttribute("control", listaControlCalidad);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;

            }

            request.getRequestDispatcher("VistaControlCalidad.jsp").forward(request, response);

            //CRUD PROVEEDOR
        } else if (menu.equals("VistaProveedor")) {
            switch (accion) {
                case "Listar":
                    List listaProveedor = proveedorDao.listar();
                    request.setAttribute("proveedores", listaProveedor);

                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaProveedor.jsp").forward(request, response);

            //CRUD ARTICULO
        } else if (menu.equals("VistaArticulo")) {
            switch (accion) {
                case "Listar":
                    List listaArticulos = articuloDao.listar();
                    request.setAttribute("articulos", listaArticulos);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaArticulo.jsp").forward(request, response);

            //CRUD EMPLEADO
        } else if (menu.equals("VistaEmpleado")) {
            switch (accion) {
                case "Listar":
                    List listaEmpleados = empleadoDAO.listarEmpleado();
                    request.setAttribute("empleados", listaEmpleados);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaEmpleado.jsp").forward(request, response);

            //CRUD DETALLE ARTICULO COMPRA
        } else if (menu.equals("VistaDetalleArticuloCompra")) {
            switch (accion) {
                case "Listar":
                    List listaDetalleArticuloCompras = detalleArticuloCompraDAO.Listar();
                    request.setAttribute("detalleArticuloCompras", listaDetalleArticuloCompras);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaDetalleArticuloCompra.jsp").forward(request, response);

            //CRUD PERSONA
        } else if (menu.equals("VistaPersona")) {
            switch (accion) {
                case "Listar":
                    List listaPersonas = personaDao.listar();
                    request.setAttribute("personas", listaPersonas);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaPersona.jsp").forward(request, response);

            //CRUD FACTURA
        } else if (menu.equals("VistaFactura")) {
            switch (accion) {
                case "Listar":
                    List listaFacturas = facturaDao.listarFactura();
                    request.setAttribute("facturas", listaFacturas);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaFactura.jsp").forward(request, response);

            //CRUD USUARIO
        } else if (menu.equals("VistaUsuario")) {
            switch (accion) {
                case "Listar":
                    List listaUsuarios = usuarioDao.Listar();
                    request.setAttribute("usuario", listaUsuarios);
                    break;
                case "Agregar":
                    String nombreUsuario = request.getParameter("txtNombreUsuario");
                    String apellidoUsuario = request.getParameter("txtApellidoUsuario");
                    String correoUsuario = request.getParameter("txtCorreoUsuario");
                    String username = request.getParameter("txtUsername");
                    String contrasena = request.getParameter("txtContrasena");
                    usuario.setNombreUsuario(nombreUsuario);
                    usuario.setApellidoUsuario(apellidoUsuario);
                    usuario.setCorreoUsuario(correoUsuario);
                    usuario.setUsername(username);
                    usuario.setContrasena(contrasena);
                    usuarioDao.agregar(usuario);
                    request.getRequestDispatcher("Controlador?menu=VistaUsuario&accion=Listar").forward(request, response);
                    break;
                /*    
                case "Editar":
                    codUsuario = Integer.parseInt(request.getParameter("txtCodigoUsuario"));
                    Usuario u = usuarioDao.listarCodigoUsuario(codUsuario);
                    request.setAttribute("usuarioEncontrado", u);
                    request.getRequestDispatcher("Controlador?menu=VistaUsuario&accion=Listar").forward(request, response);
                    break;
                 */

                case "Actualizar":
                    int codUsuarioA = Integer.parseInt(request.getParameter("txtCodigoUsuario"));
                    String nombreUsuarioE = request.getParameter("txtNombreUsuario");
                    String apellidoUsuarioE = request.getParameter("txtApellidoUsuario");
                    String correoUsuarioE = request.getParameter("txtCorreoUsuario");
                    String usernameE = request.getParameter("txtUsername");
                    String contrasenaE = request.getParameter("txtContrasena");
                    usuario.setNombreUsuario(nombreUsuarioE);
                    usuario.setApellidoUsuario(apellidoUsuarioE);
                    usuario.setCorreoUsuario(correoUsuarioE);
                    usuario.setUsername(usernameE);
                    usuario.setContrasena(contrasenaE);
                    usuario.setCodigoUsuario(codUsuarioA);
                    usuarioDao.actualizar(usuario);
                    request.getRequestDispatcher("Controlador?menu=VistaUsuario&accion=Listar").forward(request, response);
                    break;

                case "Eliminar":
                    int codUsuarioE = Integer.parseInt(request.getParameter("txtCodigoUsuario"));
                    usuarioDao.eliminar(codUsuarioE);
                    request.getRequestDispatcher("Controlador?menu=VistaUsuario&accion=Listar").forward(request, response);
                    
                    break;
            }
            request.getRequestDispatcher("VistaUsuario.jsp").forward(request, response);

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
