package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class CompraDAO {
    
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    //Método Listar
    
    public List listar(){
        String sql = "select * from Compra";
        List<Compra> listaCompra = new ArrayList<>();
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Compra comp = new Compra();
                comp.setCodigoCompra(rs.getInt(1));
                comp.setFormaDePago(rs.getString(2));
                comp.setDepartamentoEntrega(rs.getString(3));
                comp.setDireccionEntrega(rs.getString(4));
                comp.setHorarioEntrega(rs.getString(5));
                comp.setTelefonoEntrega(rs.getString(6));
                comp.setCodigoPersona(rs.getInt(7));
                listaCompra.add(comp);
                
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return listaCompra;
    }     
}
