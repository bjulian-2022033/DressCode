package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
public List Listar() {
    String sql = "Select * FROM Usuario";
        List<Usuario> listaUsuario = new ArrayList<>();
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Usuario us = new Usuario();
                us.setCodigoUsuario(rs.getInt(1));
                us.setNombreUsuario(rs.getString(2));
                us.setApellidoUsuario(rs.getString(3));
                us.setCorreoUsuario(rs.getString(4));
                us.setUsername(rs.getString(5));
                us.setContrasena(rs.getString(6));
                listaUsuario.add(us);  
            }           
        }catch (Exception e) {
            e.printStackTrace();
        }

        return listaUsuario;

}

    public int agregar(Usuario usu){
        String sql = "Insert into Usuario(?,?,?,?,?,?)";
        try{
            con = cn.Conesxion();
            ps = con.prepareStatement(sql);
            ps.setString(1, usu.getNombreUsuario());
            ps.setString(2, usu.getApellidoUsuario());
            ps.setString(3, usu.getCorreoUsuario());
            ps.setString(4, usu.getUsername());
            ps.setString(5, usu.getContrasena());
            ps.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }
        
        return resp;
        
    }
    
    public Usuario listarCodigoUsuario (int id) {
        Usuario us = new Usuario();
        String sql = "Select * from Usuario Where codigoUsuario =" + id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                us.setNombreUsuario(rs.getString(2));
                us.setApellidoUsuario(rs.getString(3));
                us.setCorreoUsuario(rs.getString(4));
                us.setUsername(rs.getString(5));
                us.setContrasena(rs.getString(6));            
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return us;
    }
    
    public int actualizar(Usuario usu) {
        String sql = "";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, usu.getNombreUsuario());
            ps.setString(2, usu.getApellidoUsuario());
            ps.setString(3, usu.getCorreoUsuario());
            ps.setString(4, usu.getUsername());
            ps.setString(5, usu.getContrasena());
            ps.setInt(6, usu.getCodigoUsuario());
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return resp;
    }
    
    public void eliminar(int id) {
        String sql = "delete from Usuario where codigoUsuario = " + id;
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    
    }
    
    
}
