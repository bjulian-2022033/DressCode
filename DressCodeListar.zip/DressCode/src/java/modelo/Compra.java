package modelo;


public class Compra {
    
    private int codigoCompra;
    private String fechaEntrega;
    private int cantidad;
    private String formaDePago;
    private String departamentoEntrega;
    private String direccionEntrega;
    private int codigoPersona;

    public Compra() {
    }

    public Compra(int codigoCompra, String fechaEntrega, int cantidad, String formaDePago, String departamentoEntrega, String direccionEntrega, int codigoPersona) {
        this.codigoCompra = codigoCompra;
        this.fechaEntrega = fechaEntrega;
        this.cantidad = cantidad;
        this.formaDePago = formaDePago;
        this.departamentoEntrega = departamentoEntrega;
        this.direccionEntrega = direccionEntrega;
        this.codigoPersona = codigoPersona;
    }

    public int getCodigoCompra() {
        return codigoCompra;
    }

    public void setCodigoCompra(int codigoCompra) {
        this.codigoCompra = codigoCompra;
    }

    public String getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(String fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getFormaDePago() {
        return formaDePago;
    }

    public void setFormaDePago(String formaDePago) {
        this.formaDePago = formaDePago;
    }

    public String getDepartamentoEntrega() {
        return departamentoEntrega;
    }

    public void setDepartamentoEntrega(String departamentoEntrega) {
        this.departamentoEntrega = departamentoEntrega;
    }

    public String getDireccionEntrega() {
        return direccionEntrega;
    }

    public void setDireccionEntrega(String direccionEntrega) {
        this.direccionEntrega = direccionEntrega;
    }

    public int getCodigoPersona() {
        return codigoPersona;
    }

    public void setCodigoPersona(int codigoPersona) {
        this.codigoPersona = codigoPersona;
    }

}
