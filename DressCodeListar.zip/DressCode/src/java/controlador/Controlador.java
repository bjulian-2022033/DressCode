/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Articulo;
import modelo.ArticuloDAO;
import modelo.Categoria;
import modelo.CategoriaDAO;
import modelo.Compra;
import modelo.CompraDAO;
import modelo.ControlCalidad;
import modelo.ControlCalidadDAO;
import modelo.DetalleArticuloCompra;
import modelo.DetalleArticuloCompraDAO;
import modelo.Empleado;
import modelo.EmpleadoDAO;
import modelo.Factura;
import modelo.FacturaDAO;
import modelo.Marca;
import modelo.MarcaDAO;
import modelo.Persona;
import modelo.PersonaDAO;
import modelo.Proveedor;
import modelo.ProveedorDAO;
import modelo.Usuario;
import modelo.UsuarioDAO;

/**
 *
 * @author al3ja
 */
@WebServlet(name = "Controlador", urlPatterns = {"/Controlador"})
public class Controlador extends HttpServlet {

    //MARCA
    Marca marca = new Marca();
    MarcaDAO marcaDao = new MarcaDAO();
    int codMarca;

    //COMPRA
    Compra compra = new Compra();
    CompraDAO compraDao = new CompraDAO();
    int codCompra;

    //CATEGORIA
    Categoria categoria = new Categoria();
    CategoriaDAO categoriaDao = new CategoriaDAO();
    int codCategoria;

    //PROVEEDOR
    Proveedor proveedor = new Proveedor();
    ProveedorDAO proveedorDao = new ProveedorDAO();
    int codProveedor;

    //CONTROL CALIDAD
    ControlCalidad controlCalidad = new ControlCalidad();
    ControlCalidadDAO controlCalidadDao = new ControlCalidadDAO();
    int codControlCalidad;

    //Articulo
    Articulo articulo = new Articulo();
    ArticuloDAO articuloDao = new ArticuloDAO();
    int codArticulo;

    // Empleado
    Empleado empleado = new Empleado();
    EmpleadoDAO empleadoDAO = new EmpleadoDAO();
    int codEmpleado;

    

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");
        if (menu.equals("Principal")) {

            request.getRequestDispatcher("Principal.jsp").forward(request, response);

            //CRUD MARCA
        } else if (menu.equals("VistaMarca")) {
            switch (accion) {
                case "Listar":
                    List listaMarcas = marcaDao.listar();
                    request.setAttribute("marcas", listaMarcas);
                    break;
                case "Agregar":
                    
                    break;
                
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaMarca.jsp").forward(request, response);

            //CRUD COMPRA
        } else if (menu.equals("VistaCompra")) {
            switch (accion) {
                case "Listar":
                    List listaCompra = compraDao.listar();
                    request.setAttribute("compra", listaCompra);
                    break;
                case "Agregar":
                    
                    break;
                case "Actualizar":
                    
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaCompra.jsp").forward(request, response);

            //CRUD CATEGORIA
        } else if (menu.equals("VistaCategoria")) {
            switch (accion) {
                case "Listar":
                    List listaCategoria = categoriaDao.listar();
                    request.setAttribute("categoria", listaCategoria);
                    break;
                case "Agregar":
                    
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaCategoria.jsp").forward(request, response);

            //CRUD CONTROL CALIDAD
        } else if (menu.equals("VistaControlCalidad")) {
            switch (accion) {
                case "Listar":
                    List listaControlCalidad = controlCalidadDao.listar();
                    request.setAttribute("control", listaControlCalidad);
                    break;
                case "Agregar":
                    
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;

            }

            request.getRequestDispatcher("VistaControlCalidad.jsp").forward(request, response);

            //CRUD PROVEEDOR
        } else if (menu.equals("VistaProveedor")) {
            switch (accion) {
                case "Listar":
                    List listaProveedor = proveedorDao.listar();
                    request.setAttribute("proveedores", listaProveedor);

                    break;
                case "Agregar":
                    
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaProveedor.jsp").forward(request, response);

            //CRUD ARTICULO
        } else if (menu.equals("VistaArticulo")) {
            switch (accion) {
                case "Listar":
                    List listaArticulos = articuloDao.listar();
                    request.setAttribute("articulos", listaArticulos);
                    break;
                case "Agregar":
                    
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaArticulo.jsp").forward(request, response);

            //CRUD EMPLEADO
        } else if (menu.equals("VistaEmpleado")) {
            switch (accion) {
                case "Listar":
                    List listaEmpleados = empleadoDAO.listarEmpleado();
                    request.setAttribute("empleados", listaEmpleados);
                    break;
                case "Agregar":
                    
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaEmpleado.jsp").forward(request, response);
        
        }
    
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
