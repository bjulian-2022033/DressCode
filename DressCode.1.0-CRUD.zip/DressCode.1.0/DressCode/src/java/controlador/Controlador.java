/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Articulo;
import modelo.ArticuloDAO;
import modelo.Categoria;
import modelo.CategoriaDAO;
import modelo.Compra;
import modelo.CompraDAO;
import modelo.ControlCalidad;
import modelo.ControlCalidadDAO;
import modelo.DetalleArticuloCompra;
import modelo.DetalleArticuloCompraDAO;
import modelo.Empleado;
import modelo.EmpleadoDAO;
import modelo.Factura;
import modelo.FacturaDAO;
import modelo.Marca;
import modelo.MarcaDAO;
import modelo.Persona;
import modelo.PersonaDAO;
import modelo.Proveedor;
import modelo.ProveedorDAO;
import modelo.Usuario;
import modelo.UsuarioDAO;

/**
 *
 * @author informatica
 */
public class Controlador extends HttpServlet {

    //Usuario
    Usuario usuario = new Usuario();
    UsuarioDAO usuarioDao = new UsuarioDAO();
    int codUsuario;

    //MARCA
    Marca marca = new Marca();
    MarcaDAO marcaDao = new MarcaDAO();
    int codMarca;

    //COMPRA
    Compra compra = new Compra();
    CompraDAO compraDao = new CompraDAO();
    int codCompra;

    //CATEGORIA
    Categoria categoria = new Categoria();
    CategoriaDAO categoriaDao = new CategoriaDAO();
    int codCategoria;

    //PROVEEDOR
    Proveedor proveedor = new Proveedor();
    ProveedorDAO proveedorDao = new ProveedorDAO();
    int codProveedor;

    //CONTROL CALIDAD
    ControlCalidad controlCalidad = new ControlCalidad();
    ControlCalidadDAO controlCalidadDao = new ControlCalidadDAO();
    int codControlCalidad;

    //Articulo
    Articulo articulo = new Articulo();
    ArticuloDAO articuloDao = new ArticuloDAO();
    int codArticulo;

    // Empleado
    Empleado empleado = new Empleado();
    EmpleadoDAO empleadoDAO = new EmpleadoDAO();
    int codEmpleado;

    //DetalleArticulocompra
    DetalleArticuloCompra detalleArticuloCompra = new DetalleArticuloCompra();
    DetalleArticuloCompraDAO detalleArticuloCompraDAO = new DetalleArticuloCompraDAO();
    int codDetalleArticuloCompra;

    // PERSONA
    Persona persona = new Persona();
    PersonaDAO personaDao = new PersonaDAO();
    int codPersona;

    //FACTURA
    Factura factura = new Factura();
    FacturaDAO facturaDao = new FacturaDAO();
    int codFactura;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");

        if (menu.equals("Principal")) {
            request.getRequestDispatcher("Principal.jsp").forward(request, response);
            //CRUD USUARIO
        } else if (menu.equals("VistaUsuario")) {
            switch (accion) {
                case "Listar":
                    List listaUsuarios = usuarioDao.Listar();
                    request.setAttribute("usuarios", listaUsuarios);
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
            }
            request.getRequestDispatcher("VistaUsuario.jsp").forward(request, response);
            //CRUD Marca
        } else if (menu.equals("VistaMarca")) {
            switch (accion) {
                case "Listar":
                    List listaMarcas = marcaDao.listar();
                    request.setAttribute("marcas", listaMarcas);

 

                    List listaProveedor = proveedorDao.listar();
                    request.setAttribute("proveedores", listaProveedor);
                    break;
                case "Agregar":
                    String nameMarca = request.getParameter("txtNombreMarca");
                    String direcMarca = request.getParameter("txtDireccionMarca");
                    String corrMarca = request.getParameter("txtCorreoMarca");
                    int codProvee = Integer.parseInt(request.getParameter("txtCodigoProveedor"));
                    marca.setNombreMarca(nameMarca);
                    marca.setDireccionMarca(direcMarca);
                    marca.setCorreoMarca(corrMarca);
                    marca.setCodigoProveedor(codProvee);
                    marcaDao.agregar(marca);
                    request.getRequestDispatcher("Controlador?menu=VistaMarca&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    int codMarcaA = Integer.parseInt(request.getParameter("txtCodigoMarca"));
                    String nameMarcaA = request.getParameter("txtNombreMarca");
                    String direcMarcaA = request.getParameter("txtDireccionMarca");
                    String corrMarcaA = request.getParameter("txtCorreoMarca");
                    marca.setNombreMarca(nameMarcaA);
                    marca.setDireccionMarca(direcMarcaA);
                    marca.setCorreoMarca(corrMarcaA);
                    marca.setCodigoMarca(codMarcaA);
                    marcaDao.actualizar(marca);
                    request.getRequestDispatcher("Controlador?menu=VistaMarca&accion=Listar").forward(request, response);
                    break;
                case "Eliminar":
                    codMarca = Integer.parseInt(request.getParameter("txtCodigoMarca"));
                    marcaDao.eliminar(codMarca);
                    request.getRequestDispatcher("Controlador?menu=VistaMarca&accion=Listar").forward(request, response);
                    break;
            }
            request.getRequestDispatcher("VistaMarca.jsp").forward(request, response);
            // CRUD COMPRA
        } else if (menu.equals("VistaCompra")) {
            switch (accion) {
                case "Listar":
                    List listaCompra = compraDao.listar();
                    request.setAttribute("compra", listaCompra);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaCompra.jsp").forward(request, response);

            //CRUD CATEGORIA
        } else if (menu.equals("VistaCategoria")) {
            switch (accion) {
                case "Listar":
                    List listaCategoria = categoriaDao.listar();
                    request.setAttribute("categoria", listaCategoria);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaCategoria.jsp").forward(request, response);

            //CRUD CONTROL CALIDAD
        } else if (menu.equals("VistaControlCalidad")) {
            switch (accion) {
                case "Listar":
                    List listaControlCalidad = controlCalidadDao.listar();
                    request.setAttribute("control", listaControlCalidad);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;

            }

            request.getRequestDispatcher("VistaControlCalidad.jsp").forward(request, response);

            //CRUD PROVEEDOR
        } else if (menu.equals("VistaProveedor")) {
            switch (accion) {
                case "Listar":
                    List listaProveedor = proveedorDao.listar();
                    request.setAttribute("proveedores", listaProveedor);

                    break;
                
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaProveedor.jsp").forward(request, response);

            //CRUD ARTICULO
        } else if (menu.equals("VistaArticulo")) {
            switch (accion) {
                case "Listar":
                    List listaArticulos = articuloDao.listar();
                    request.setAttribute("articulos", listaArticulos);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaArticulo.jsp").forward(request, response);

            //CRUD EMPLEADO
        } else if (menu.equals("VistaEmpleado")) {
            switch (accion) {
                case "Listar":
                    //Guardamos los datos en la lista a través del método listar.
                    List listaEmpleados = empleadoDAO.listarEmpleado();
                    //Asignamos el objeto que los engloba para asignarlos en la tabla del JSP.
                    request.setAttribute("empleados", listaEmpleados);
                    break;
                case "Agregar":
                    // Asignamos los datos del JSP en variables.
                    String nomEmpleado = request.getParameter("txtNombreEmpleado");
                    String apellEmpleado = request.getParameter("txtApellidoEmpleado");
                    String puestEmpleado = request.getParameter("txtPuestoEmpleado");
                    String telEmpleado = request.getParameter("txtTelefonoEmpleado");
                    // Mandamos a asignar los datos directo en el modelo.
                    empleado.setNombreEmpleado(nomEmpleado);
                    empleado.setApellidoEmpleado(apellEmpleado);
                    empleado.setPuestoEmpleado(puestEmpleado);
                    empleado.setTelefonoEmpleado(telEmpleado);
                    //Llamamos al método Agregar.
                    empleadoDAO.agregarEmpleado(empleado);
                    //Redireccionamos a Listar para observar los cambios.
                    request.getRequestDispatcher("Controlador?menu=VistaEmpleado&accion=Listar").forward(request, response);
                    
                    break;
                case "Editar":
                   /* //Guardamos el código empleado del texto de JSP.
                    codEmpleado = Integer.parseInt(request.getParameter("txtCodigoEmpleado"));
                    //Mandamos al método de Listar.
                    Empleado e = empleadoDAO.listarCodigoEmpleado(codEmpleado);
                    //Seteamos el atributo con los datos obtenidos del listar para asignarlos en los textos JSP.
                    request.setAttribute("empleadoEncontrado", e);
                    //Redireccionamos a Listar para observar los cambios.
                    request.getRequestDispatcher("Controlador?menu=VistaEmpleado&accion=Listar").forward(request, response);*/
                    
                    break;
                case "Actualizar":
                    // Asignamos los datos obtenidos de JSP en varibales para actualizarlo.
                    int codEmpleadoA = Integer.parseInt(request.getParameter("txtCodigoEmpleado"));
                    String nomEmpleadoE = request.getParameter("txtNombreEmpleado");
                    String apellEmpleadoE = request.getParameter("txtApellidoEmpleado");
                    String puestEmpleadoE = request.getParameter("txtPuestoEmpleado");
                    String telEmpleadoE = request.getParameter("txtTelefonoEmpleado");
                    // Seteamos los cambios en el modelo.
                    empleado.setNombreEmpleado(nomEmpleadoE);
                    empleado.setApellidoEmpleado(apellEmpleadoE);
                    empleado.setPuestoEmpleado(puestEmpleadoE);
                    empleado.setTelefonoEmpleado(telEmpleadoE);
                    empleado.setCodigoEmpleado(codEmpleadoA);
                    //Mandamos los cambios junto con el código para ejecutar la sentencia.
                    empleadoDAO.actualizarEmpleado(empleado);
                    //Redireccionamos a Listar para observar los cambios.
                    request.getRequestDispatcher("Controlador?menu=VistaEmpleado&accion=Listar").forward(request, response);
                    break;
                case "Eliminar":
                    // Obtenemos el código del elemento seleccionado para eliminarlo.
                    int codEmpleadoE = Integer.parseInt(request.getParameter("txtCodigoEmpleado"));
                    //Eliminamos al empleado.
                    empleadoDAO.eliminarEmpleado(codEmpleadoE);
                    //Redireccionamos a Listar para observar los cambios.
                    request.getRequestDispatcher("Controlador?menu=VistaEmpleado&accion=Listar").forward(request, response);
                    break;
            }

            request.getRequestDispatcher("VistaEmpleado.jsp").forward(request, response);

            //CRUD DETALLE ARTICULO COMPRA
        } else if (menu.equals("VistaDetalleArticuloCompra")) {
            switch (accion) {
                case "Listar":
                    List listaDetalleArticuloCompras = detalleArticuloCompraDAO.Listar();
                    request.setAttribute("detalleArticuloCompras", listaDetalleArticuloCompras);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaDetalleArticuloCompra.jsp").forward(request, response);

            //CRUD PERSONA
        } else if (menu.equals("VistaPersona")) {
            switch (accion) {
                case "Listar":
                    List listaPersonas = personaDao.listar();
                    request.setAttribute("personas", listaPersonas);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaPersona.jsp").forward(request, response);

            //CRUD FACTURA
        } else if (menu.equals("VistaFactura")) {
            switch (accion) {
                case "Listar":
                    List listaFacturas = facturaDao.listarFactura();
                    request.setAttribute("facturas", listaFacturas);
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                case "Editar":
                    break;
            }

            request.getRequestDispatcher("VistaFactura.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
