package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class CompraDAO {
    
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    //Método Listar
    
    public List listar(){
        String sql = "select * from Compra";
        List<Compra> listaCompra = new ArrayList<>();
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Compra comp = new Compra();
                comp.setCodigoCompra(rs.getInt(1));
                comp.setFechaEntrega(rs.getString(2));
                comp.setCantidad(rs.getInt(3));
                comp.setFormaDePago(rs.getString(4));
                comp.setDepartamentoEntrega(rs.getString(5));
                comp.setDireccionEntrega(rs.getString(6));
                comp.setCodigoPersona(rs.getInt(7));
                listaCompra.add(comp);
                
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return listaCompra;
    }
    
    //Método Agregar
    public int agregar(Compra comp){
        String sql = "Insert into ControlCompra(codigoPersona, fechaCompra, horaCompra, cantidad, formaPago, departamentoEntrega, direccionEntrega) values (?,?,?,?,?,?,?)";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, comp.getFechaEntrega());
            ps.setInt(2, comp.getCantidad());
            ps.setString(3, comp.getFormaDePago());
            ps.setString(4, comp.getDepartamentoEntrega());
            ps.setString(5, comp.getDireccionEntrega());
            ps.setInt(6, comp.getCodigoPersona());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resp;
    }
    
    //Método Buscar
    
    public Compra listarCodigoCompra(int id){
        Compra comp = new Compra();
        String sql = "select * from Compra where codigoCompra = " + id;
        
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                comp.setFechaEntrega(rs.getString(2));
                comp.setCantidad(rs.getInt(3));
                comp.setFormaDePago(rs.getString(4));
                comp.setDepartamentoEntrega(rs.getString(5));
                comp.setDireccionEntrega(rs.getString(6));
                comp.setCodigoPersona(rs.getInt(7));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return comp;
    }
    
   
    //Metodo Editar
    
    public int actualizar (Compra comp){
        String sql = "update Compra set fechaEntrega = ?, cantidad = ?, formaDePago = ?, departamentoEntrega = ?, direccoionEntrega = ?, codigoPersona = ?";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, comp.getFechaEntrega());
            ps.setInt(2, comp.getCantidad());
            ps.setString(3, comp.getFormaDePago());
            ps.setString(4, comp.getDepartamentoEntrega());
            ps.setString(5, comp.getDireccionEntrega());
            ps.setInt(6, comp.getCodigoPersona());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return resp;
    }
    
    //Método Eliminar
    
    public void eliminar (int id){
        String sql = "delete from Compra where codigoCOmpra = " + id;
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
            
}
